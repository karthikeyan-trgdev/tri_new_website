<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Toprock Interiors</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.css" />
</head>

<body>
    <div id="smooth-wrapper">
        <div id="smooth-content">

    <!-- Preloader (This will curve up) -->
    <div class="preloader" id="preloader">
        <div class="preloader-logo" id="logo">
            <img src="assets/images/tri-logo-white.png" alt="">
        </div>
        <div class="preloader-counter" id="counter">0</div>
        <div class="progress-container">
            <div class="progress-bar" id="progressBar"></div>
        </div>
        <div class="loading-text">Loading</div>
    </div>

            <header>
                <nav class="navbar navbar-expand-lg primary_header">
                    <div class="container">
                        <div class="header-logo">
                            <a class="navbar-brand" href="#">
                                <img src="assets/images/tri-logo-white.png" alt="">
                            </a>
                        </div>
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav m-auto mb-2 mb-lg-0">
                                <li class="nav-item">
                                    <a class="nav-link active" aria-current="page" href="#">Home</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" aria-current="page" href="#">About</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" aria-current="page" href="#">Services</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" aria-current="page" href="#">Sectors</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" aria-current="page" href="#">Blogs</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" aria-current="page" href="#">Projects</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" aria-current="page" href="#">Career</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" aria-current="page" href="#">Contact</a>
                                </li>
                                <!-- <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                About us
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="#">Who we are</a></li>
                                <li><a class="dropdown-item" href="#">Management Team</a></li>
                                <li><a class="dropdown-item" href="#">Network</a></li>
                                <li><a class="dropdown-item" href="#">Testimonials</a></li>
                                <li><a class="dropdown-item" href="#">Certifications</a></li>
                            </ul>
                        </li> -->
                            </ul>
                            <form class="d-flex" role="search">
                                <button class="light-theme-btn" type="submit">Get a Quote</button>
                            </form>
                        </div>
                    </div>
                </nav>
            </header>

            <div class="Home_bnr">
                <div class="sliderWrapper">
                    <div class="sliderImage">
                        <img src="assets/images/banner-1.jpg" alt="">
                    </div>
                    <div class="sliderImage">
                        <img src="assets/images/banner-2.jpg" alt="">
                    </div>
                    <div class="sliderImage">
                        <img src="assets/images/banner-3.jpg" alt="">
                    </div>
                </div>

                <div class="carousel_caption">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12">
                                <div id="hero_slider" class="owl-carousel owl-theme">
                                    <div class="item">
                                        <div class="banner-content">
                                            <h1>Design.</h1>
                                            <h1>Build.</h1>
                                            <h1><span>Inspire.</span></h1>
                                            <p>We create thoughtfully designed interiors that blend aesthetics with functionality. <br>From concept to completion, our team transforms spaces into inspiring environments <br>tailored to your lifestyle and vision.</p>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="banner-content">
                                            <h1>Design.</h1>
                                            <h1>Build.</h1>
                                            <h1><span>Inspire.</span></h1>
                                            <p>We create thoughtfully designed interiors that blend aesthetics with functionality. <br>From concept to completion, our team transforms spaces into inspiring environments <br>tailored to your lifestyle and vision.</p>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="banner-content">
                                            <h1>Design.</h1>
                                            <h1>Build.</h1>
                                            <h1><span>Inspire.</span></h1>
                                            <p>We create thoughtfully designed interiors that blend aesthetics with functionality. <br>From concept to completion, our team transforms spaces into inspiring environments <br>tailored to your lifestyle and vision.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <section class="section-padding about-section ">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-5">
                            <div class="section-title">
                                <h1>Excellence Through Experience</h1>
                                <p>Over 20 years of shaping interiors that reflect vision, craftsmanship, and trust. Over 20 years of shaping interiors that reflect vision, craftsmanship, and trust.</p>
                            </div>
                            <button class="light-theme-btn" type="submit">Know More</button>
                            <div class="experience-count">
                                <h1>20+</h1>
                                <h5>Years of Experience</h5>
                            </div>
                        </div>
                        <div class="col-lg-7">
                            <div class="cards-animations">
                                <div class="card card-1">
                                    <div class="number">
                                        <h1>55K+</h1>
                                    </div>
                                    <div class="words">
                                        <h1>Happy Clients</h1>
                                    </div>
                                </div>
                                <div class="card card-2">
                                    <div class="number">
                                        <h1>4K+</h1>
                                    </div>
                                    <div class="words">
                                        <h1>Smart City Projects</h1>
                                    </div>
                                </div>
                                <div class="card card-3">
                                    <div class="number">
                                        <h1>5+</h1>
                                    </div>
                                    <div class="words">
                                        <h1>Services</h1>
                                    </div>
                                </div>
                                <div class="card card-4">
                                    <div class="number">
                                        <h1>105+</h1>
                                    </div>
                                    <div class="words">
                                        <h1>Projects Handled</h1>
                                    </div>
                                </div>
                                <div class="card card-5">
                                    <div class="number">
                                        <h1>52+</h1>
                                    </div>
                                    <div class="words">
                                        <h1>Corporate Interiors</h1>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section class="section-padding who-we-serve  pt-0">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6">
                            <div id="who_serve" class="owl-carousel owl-theme">
                                <div class="item">
                                    <div class="image-box">
                                        <img src="assets/images/sectors/corporate.jpg" alt="">
                                        <div class="content">
                                            <h1>CORPORATE</h1>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="image-box">
                                        <img src="assets/images/sectors/retail.jpg" alt="">
                                        <div class="content">
                                            <h1>RETAIL</h1>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="image-box">
                                        <img src="assets/images/sectors/f-and-b.jpg" alt="">
                                        <div class="content">
                                            <h1>FOOD & BEVERAGES</h1>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="image-box">
                                        <img src="assets/images/sectors/health.jpg" alt="">
                                        <div class="content">
                                            <h1>LEISURE & HEALTH</h1>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="image-box">
                                        <img src="assets/images/sectors/airport.jpg" alt="">
                                        <div class="content">
                                            <h1>AIRPORT INTERIORS</h1>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 sec-gap-left">
                            <div class="section-title">
                                <h1>Who we serve</h1>
                                <p>At Top Rock, we are passionate about what we do. We are committed to deliver high quality interior fit-out solutions that are sustainable,
                                    innovative and efficient. Our strong reputation is founded on exemplary service, working closely with our clients to ensure that the end product is aligned to their brand.</p>
                            </div>
                            <button class="light-theme-btn" type="submit">Get a Quote</button>
                        </div>
                    </div>
                </div>
            </section>

            <section class="text-reveal-sec section-padding">
                <div class="container">
                    <div class="row">
                        <h1>Established in 2004, TRI has become a leading name in Dubai's premium interior design and fit-out industry. With over 2,000+ successful projects for top brands.</h1>
                    </div>
                </div>
            </section>

            <section class=" section-padding testimonial-section">
                <div class="container">
                    <div class="row navigation-title">
                        <div class="col-lg-6">
                            <div class="section-title">
                                <h1>Testimonials</h1>
                                <p>Explore the impact of our services
                                    through the voices of our clients.</p>
                            </div>
                        </div>
                        <div class="col-lg-6 arrow-btn-column">
                            <div class="arrow-btn">
                                <img src="assets/images/arrow.png" alt="">
                            </div>
                        </div>
                    </div>
                    <div class="row testi-card-row">
                        <div class="col-lg-4">
                            <div class="card">
                                <div class="icon">
                                    <img src="assets/images/quote-icon.svg" alt="">
                                </div>
                                <div class="content">
                                    <p>I had the pleasure of visiting TopRock Interiors' factory during my trip to Dubai. Their impressive work on my uncle's Dubai outlet Their impressive work on my uncle's Dubai outlet Their impressive work on my uncle's Dubai outlet Their impressive work on my uncle's Dubai outlet</p>
                                </div>
                                <div class="profile">
                                    <img src="assets/images/profile-icon.png" alt="">
                                    <h6>Nikhil Kumaresan</h6>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="card card-2">
                                <div class="icon">
                                    <img src="assets/images/quote-icon.svg" alt="">
                                </div>
                                <div class="content">
                                    <p>I had the pleasure of visiting TopRock Interiors' factory during my trip to Dubai. Their impressive work on my uncle's Dubai outlet Their impressive work on my uncle's Dubai outlet Their impressive work on my uncle's Dubai outlet Their impressive work on my uncle's Dubai outlet</p>
                                </div>
                                <div class="profile">
                                    <img src="assets/images/profile-icon.png" alt="">
                                    <h6>Nikhil Kumaresan</h6>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="card">
                                <div class="icon">
                                    <img src="assets/images/quote-icon.svg" alt="">
                                </div>
                                <div class="content">
                                    <p>I had the pleasure of visiting TopRock Interiors' factory during my trip to Dubai. Their impressive work on my uncle's Dubai outlet Their impressive work on my uncle's Dubai outlet Their impressive work on my uncle's Dubai outlet Their impressive work on my uncle's Dubai outlet</p>
                                </div>
                                <div class="profile">
                                    <img src="assets/images/profile-icon.png" alt="">
                                    <h6>Nikhil Kumaresan</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>


            <section class="client-section  section-padding">
                <div class="container-fluid">
                    <div class="row">
                        <div class="text-center section-title">
                            <h1>Our Valuable Customers</h1>
                            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Reprehenderit nam eius nihil voluptate <br>dignissimos iure accusantium quia magni officiis harum?</p>
                        </div>
                        <div id="client_slider" class="owl-carousel owl-theme">
                            <div class="item">
                                <div class="logo">
                                    <img src="assets/images/clients/client-1.png" alt="">
                                </div>
                            </div>
                            <div class="item">
                                <div class="logo">
                                    <img src="assets/images/clients/client-2.png" alt="">
                                </div>
                            </div>
                            <div class="item">
                                <div class="logo">
                                    <img src="assets/images/clients/client-3.png" alt="">
                                </div>
                            </div>
                            <div class="item">
                                <div class="logo">
                                    <img src="assets/images/clients/client-4.png" alt="">
                                </div>
                            </div>
                            <div class="item">
                                <div class="logo">
                                    <img src="assets/images/clients/client-5.png" alt="">
                                </div>
                            </div>
                            <div class="item">
                                <div class="logo">
                                    <img src="assets/images/clients/client-6.png" alt="">
                                </div>
                            </div>
                            <div class="item">
                                <div class="logo">
                                    <img src="assets/images/clients/client-7.png" alt="">
                                </div>
                            </div>


                        </div>
                        <div id="client_slider_two" class="owl-carousel owl-theme">
                            <div class="item">
                                <div class="logo">
                                    <img src="assets/images/clients/client-1.png" alt="">
                                </div>
                            </div>
                            <div class="item">
                                <div class="logo">
                                    <img src="assets/images/clients/client-2.png" alt="">
                                </div>
                            </div>
                            <div class="item">
                                <div class="logo">
                                    <img src="assets/images/clients/client-3.png" alt="">
                                </div>
                            </div>
                            <div class="item">
                                <div class="logo">
                                    <img src="assets/images/clients/client-4.png" alt="">
                                </div>
                            </div>
                            <div class="item">
                                <div class="logo">
                                    <img src="assets/images/clients/client-5.png" alt="">
                                </div>
                            </div>
                            <div class="item">
                                <div class="logo">
                                    <img src="assets/images/clients/client-6.png" alt="">
                                </div>
                            </div>
                            <div class="item">
                                <div class="logo">
                                    <img src="assets/images/clients/client-7.png" alt="">
                                </div>
                            </div>


                        </div>
                    </div>
                </div>
            </section>


            <section class=" section-padding project-section">
                <div class="container">
                    <div class="row navigation-title">
                        <div class="col-lg-6">
                            <div class="section-title">
                                <h1>Projects</h1>
                                <p>Explore the impact of our services
                                    through the voices of our clients.</p>
                            </div>
                        </div>
                        <div class="col-lg-6 arrow-btn-column">
                            <div class="arrow-btn">
                                <img src="assets/images/arrow.png" alt="">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="container-fluid">
                    <div class="row">
                        <div class="project-cards">
                            <img src="assets/images/projects/project-1.jpg" alt="">
                            <div class="project-detail">
                                <div class="number">
                                    <h1>01</h1>
                                </div>
                                <div class="name">
                                    <h3>ETHIAD</h3>
                                    <h6>- DUBAI</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>


            <section class=" section-padding certificate-section pt-0">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6">
                            <div id="certificate_slider" class="owl-carousel owl-theme">
                                <div class="item">
                                    <img src="assets/images/certificate/certificate-1.png" alt="">
                                </div>
                                <div class="item">
                                    <img src="assets/images/certificate/certificate-1.png" alt="">
                                </div>
                                <div class="item">
                                    <img src="assets/images/certificate/certificate-1.png" alt="">
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="section-title sec-gap-left">
                                <h1>We are Certified</h1>
                                <p>TRI is committed to a Policy for Continual Improvement in the performance of our Quality, Occupational Health & Safety and Environmental Management Systems for our services that include: Plumbing and Sanitary Contracting, Electrical Fitting Contracting, Floor and Wall Tilling Works.</p>
                                <button class="light-theme-btn" type="submit">Explore</button>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section class="">
                <div class="sliding_cta">
                    <div class="container">
                        <div class="row">
                            <div class="section-title text-center">
                                <h1 class="mb-5">Get the Latest <br>updates and News</h1>
                                <button class="bg-btn" type="submit">Get Latest Updates</button>
                            </div>
                        </div>
                    </div>
                </div>
            </section>


            <section class=" section-padding moments-section">
                <div class="container">
                    <div class="row">
                        <div class="section-title text-end">
                            <h1>Moments of Excellence</h1>
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quo laudantium cum <br>officia consequatur, consectetur cumque incidunt culpa ullam autem itaque?</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-4">

                            <div class="card">
                                <div class="img-box">
                                    <img src="assets/images/moments/excellence-1.png" alt="">
                                </div>

                                <div class="play-icon">
                                    <i class="fa-solid fa-play"></i>
                                </div>

                                <div class="content">
                                    <h1>Video Title</h1>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4">

                            <div class="card">
                                <div class="img-box">
                                    <img src="assets/images/moments/excellence-2.jpg" alt="">
                                </div>

                                <div class="play-icon">
                                    <i class="fa-solid fa-play"></i>
                                </div>

                                <div class="content">
                                    <h1>Video Title</h1>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4">

                            <div class="card">
                                <div class="img-box">
                                    <img src="assets/images/moments/excellence-3.jpg" alt="">
                                </div>

                                <div class="play-icon">
                                    <i class="fa-solid fa-play"></i>
                                </div>

                                <div class="content">
                                    <h1>Video Title</h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>


            <section class=" section-padding latest-news pt-0">
                <div class="container">
                    <div class="row navigation-title">
                        <div class="col-lg-8">
                            <div class="section-title">
                                <h1>Latest News</h1>
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quo laudantium cum <br>officia consequatur, consectetur cumque incidunt culpa ullam autem itaque?</p>
                            </div>
                        </div>
                        <div class="col-lg-4 arrow-btn-column">
                            <div class="arrow-btn">
                                <img src="assets/images/arrow.png" alt="">
                            </div>
                        </div>
                    </div>
                    <div class="row pt-5">
                        <div class="col-lg-4">
                            <div class="card">
                                <div class="image">
                                    <img src="assets/images/news/news-1.jpg" alt="">
                                    <div class="date">
                                        <h6>Jan 07, 2026</h6>
                                    </div>
                                </div>
                                <div class="content">
                                    <h1>Lorem ipsum dolor sit amet consectetur adipisicing.</h1>
                                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Iusto, animi placeat quae eius reiciendis maiores totam voluptatibus reprehenderit? Delectus, nam!</p>
                                    <h6>Read More</h6>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4">
                            <div class="card">
                                <div class="image">
                                    <img src="assets/images/news/news-1.jpg" alt="">
                                    <div class="date">
                                        <h6>Jan 07, 2026</h6>
                                    </div>
                                </div>
                                <div class="content">
                                    <h1>Lorem ipsum dolor sit amet consectetur adipisicing.</h1>
                                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Iusto, animi placeat quae eius reiciendis maiores totam voluptatibus reprehenderit? Delectus, nam!</p>
                                    <h6>Read More</h6>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4">
                            <div class="card">
                                <div class="image">
                                    <img src="assets/images/news/news-1.jpg" alt="">
                                    <div class="date">
                                        <h6>Jan 07, 2026</h6>
                                    </div>
                                </div>
                                <div class="content">
                                    <h1>Lorem ipsum dolor sit amet consectetur adipisicing.</h1>
                                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Iusto, animi placeat quae eius reiciendis maiores totam voluptatibus reprehenderit? Delectus, nam!</p>
                                    <h6>Read More</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>



            <section class=" section-padding home-faq-section">
                <div class="container">
                    <div class="row faq-sec-row">
                        <div class="col-lg-6">
                            <div class="section-title">
                                <h1>Frequently Asked Questions</h1>
                                <p>At Top Rock, we are passionate about what we do. We are committed to deliver high quality interior fit-out solutions that are sustainable, innovative and efficient. Our strong reputation is founded on exemplary service, working closely with our clients to ensure that the end product is aligned to their brand.</p>
                                <button class="light-theme-btn" type="submit">View All FAQ's</button>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="accordion" id="accordionExample">
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingOne">
                                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                            What areas do you serve?
                                        </button>
                                    </h2>
                                    <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <p>We operate across the UAE, including Dubai and Abu Dhabi, and have offices in Qatar, Bahrain, Saudi Arabia, and India.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingTwo">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                            What type of project do you handle?
                                        </button>
                                    </h2>
                                    <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <p>We operate across the UAE, including Dubai and Abu Dhabi, and have offices in Qatar, Bahrain, Saudi Arabia, and India.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingThree">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                            Do you handle design and build projects end-to-end?
                                        </button>
                                    </h2>
                                    <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <p>We operate across the UAE, including Dubai and Abu Dhabi, and have offices in Qatar, Bahrain, Saudi Arabia, and India.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingThree">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                            What certifications do you hold?
                                        </button>
                                    </h2>
                                    <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <p>We operate across the UAE, including Dubai and Abu Dhabi, and have offices in Qatar, Bahrain, Saudi Arabia, and India.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingThree">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                                            How long have you been in business?
                                        </button>
                                    </h2>
                                    <div id="collapseFive" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <p>We operate across the UAE, including Dubai and Abu Dhabi, and have offices in Qatar, Bahrain, Saudi Arabia, and India.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>


            <section class="cta-section  section-padding">
                <div class="container">
                    <div class="row">
                        <div class="section-title large-section-title text-center">
                            <h1>Let us Craft <br>your Space</h1>
                            <button class="bg-btn mt-5" type="submit">Connect Now</button>
                        </div>
                    </div>
                </div>
            </section>



            <footer class=" section-padding footer-section pb-0">
                <div class="container">
                    <div class="top-footer">
                        <div class="row">
                            <div class="col-lg-4">
                                <div class="logo">
                                    <img src="assets/images/tri-logo-white.png" alt="">
                                </div>
                                <p>Established in 2004, TRI has become a leading name in Dubai’s premium interior design and fit-out industry. With over 2,000+ successful projects for top brands, we bring extensive experience and unparalleled craftsmanship to every endeavor.</p>
                            </div>
                            <div class="col-lg-2">
                                <div class="footer-title">
                                    <h1>Quick Links</h1>
                                </div>
                                <div class="footer-menu-items">
                                    <ul>
                                        <li>Home</li>
                                        <li>About us</li>
                                        <li>Services</li>
                                        <li>Sectors</li>
                                        <li>Contact Us</li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-lg-2">
                                <div class="footer-title">
                                    <h1>Sectors</h1>
                                </div>
                                <div class="footer-menu-items">
                                    <ul>
                                        <li>Corporate</li>
                                        <li>Retail</li>
                                        <li>Food & Beverages</li>
                                        <li>Leisure & Health</li>
                                        <li>Airport</li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="footer-title">
                                    <h1>Contact Us</h1>
                                </div>
                                <div class="footer-menu-items contact-items">
                                    <ul>
                                        <li>
                                            <i class="fa-solid fa-location-dot"></i>
                                            <h6>Office No.1 Al Qusais Industrial Area 2, <br>Al Qusais, Dubai.</h6>
                                        </li>
                                        <li>
                                            <i class="fa-solid fa-phone"></i>
                                            <h6>+971 42678095</h6>
                                        </li>
                                        <li>
                                            <i class="fa-solid fa-envelope"></i>
                                            <h6>info@toprockinteriors.com</h6>
                                        </li>
                                        <li>
                                            <i class="fa-solid fa-globe"></i>
                                            <h6>www.toprockinteriors.com</h6>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="bottom-footer">
                        <div class="left-content">
                            <p>
                                Copyright © TOPROCK INTERIORS –
                                <script>
                                    document.write(new Date().getFullYear());
                                </script>
                                All Rights Reserved
                            </p>
                        </div>
                        <div class="right-content">
                            <ul>
                                <li>Terms & Conditions</li>
                                <li>Privacy Policy</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </div>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/js/all.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js"></script>

    <script src="https://unpkg.com/gsap@3/dist/gsap.min.js"></script>
    <script src="https://unpkg.com/gsap@3/dist/ScrollTrigger.min.js"></script>
    <script src="https://unpkg.com/gsap@3/dist/ScrollSmoother.min.js"></script>


    <script src="assets/js/script.js"></script>


</body>

</html>